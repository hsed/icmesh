#include "mbed.h"
#include "LSM303DLHC.h"
//#include "vector.h"
 
Serial debug(USBTX,USBRX);
LSM303DLHC compass(p28, p27);
 
int main() {
   debug.format(8,Serial::None,1);
   debug.baud(115200);
   debug.printf("LSM303DLH Test\x0d\x0a");
   //compass.setOffset(29.50, -0.50, 4.00); // example calibration
   //compass.setScale(1.00, 1.03, 1.21);    // example calibration
   float ax, ay, az, mx, my, mz;
   while(1) {
     //hdg = compass.heading();
     compass.read(&ax, &ay, &az, &mx, &my, &mz);
     //debug.printf("Heading: %.2f\n", hdg);
     //debug.printf("A: %.2f", ax);
     debug.printf("A: %.2f %.2f %.2f \n", ax, ay, az);
     //debug.printf("M: %.2f\t%.2f\t%.2f\n", m.x, m.y, m.z);
     wait(0.1);
     
   }
 }