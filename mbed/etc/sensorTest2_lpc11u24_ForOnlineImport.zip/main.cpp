#include "mbed.h"
#include "LSM303DLHC.h"
//This uses the new 2013 library (limited function), Result is smaller numbers and more responsive, could be in terms of g??
//Printing float causes problems when compiling makefile.

Serial debug(USBTX,USBRX);
LSM303DLHC compass(p28, p27);
 
int main() {
   debug.format(8,Serial::None,1);
   debug.baud(115200);
   debug.printf("LSM303DLH Test\x0d\x0a");
   //compass.setOffset(29.50, -0.50, 4.00); // example calibration
   //compass.setScale(1.00, 1.03, 1.21);    // example calibration
   float ax, ay, az, mx, my, mz;
   while(1) {
     //hdg = compass.heading();
     compass.read(&ax, &ay, &az, &mx, &my, &mz);
     //debug.printf("Heading: %.2f\n", hdg);
     //debug.printf("A: %.2f", ax);
     debug.printf("A: %4.2f %4.2f %4.2f   ", ax, ay, az);
     debug.printf("M: %4.2f\t%4.2f\t%4.2f\n", mx, my, mz);
     wait(0.1);
     
   }
 }